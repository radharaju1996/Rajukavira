```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os 
import warnings
warnings.filterwarnings('ignore')
```

# Reading Data set 3


```python
df = pd.read_excel(r'C:\Users\RAJUK\Downloads\dataset_3.xlsx')
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>instant</th>
      <th>dteday</th>
      <th>season</th>
      <th>yr</th>
      <th>mnth</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>weathersit</th>
      <th>temp</th>
      <th>atemp</th>
      <th>hum</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>cnt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>620</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1940</td>
      <td>0</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>621</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1642</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>622</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.20</td>
      <td>0.2121</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>623</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.69</td>
      <td>0.1045</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>624</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>385</th>
      <td>615</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
    </tr>
    <tr>
      <th>386</th>
      <td>616</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
    </tr>
    <tr>
      <th>387</th>
      <td>617</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2121</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>388</th>
      <td>618</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
    </tr>
    <tr>
      <th>389</th>
      <td>619</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.1970</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
    </tr>
  </tbody>
</table>
<p>390 rows × 16 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 390 entries, 0 to 389
    Data columns (total 16 columns):
     #   Column      Non-Null Count  Dtype         
    ---  ------      --------------  -----         
     0   instant     390 non-null    int64         
     1   dteday      390 non-null    datetime64[ns]
     2   season      390 non-null    int64         
     3   yr          390 non-null    int64         
     4   mnth        390 non-null    int64         
     5   hr          390 non-null    int64         
     6   holiday     390 non-null    bool          
     7   weekday     390 non-null    int64         
     8   weathersit  390 non-null    int64         
     9   temp        390 non-null    float64       
     10  atemp       390 non-null    float64       
     11  hum         390 non-null    float64       
     12  windspeed   390 non-null    float64       
     13  casual      390 non-null    int64         
     14  registered  390 non-null    int64         
     15  cnt         390 non-null    int64         
    dtypes: bool(1), datetime64[ns](1), float64(4), int64(10)
    memory usage: 46.2 KB
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>instant</th>
      <th>dteday</th>
      <th>season</th>
      <th>yr</th>
      <th>mnth</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>weathersit</th>
      <th>temp</th>
      <th>atemp</th>
      <th>hum</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>cnt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>620</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1940</td>
      <td>0</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>621</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1642</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>622</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.20</td>
      <td>0.2121</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>623</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.69</td>
      <td>0.1045</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>624</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>instant</th>
      <th>dteday</th>
      <th>season</th>
      <th>yr</th>
      <th>mnth</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>weathersit</th>
      <th>temp</th>
      <th>atemp</th>
      <th>hum</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>cnt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>385</th>
      <td>615</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
    </tr>
    <tr>
      <th>386</th>
      <td>616</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
    </tr>
    <tr>
      <th>387</th>
      <td>617</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2121</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>388</th>
      <td>618</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
    </tr>
    <tr>
      <th>389</th>
      <td>619</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.1970</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    instant       0
    dteday        0
    season        0
    yr            0
    mnth          0
    hr            0
    holiday       0
    weekday       0
    weathersit    0
    temp          0
    atemp         0
    hum           0
    windspeed     0
    casual        0
    registered    0
    cnt           0
    dtype: int64




```python
df.duplicated().sum()
```




    0




```python
df1 = df.drop("yr", axis=1)
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>instant</th>
      <th>dteday</th>
      <th>season</th>
      <th>mnth</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>weathersit</th>
      <th>temp</th>
      <th>atemp</th>
      <th>hum</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>cnt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>620</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1940</td>
      <td>0</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>621</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1642</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>622</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.20</td>
      <td>0.2121</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>623</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.69</td>
      <td>0.1045</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>624</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>6</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>385</th>
      <td>615</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
    </tr>
    <tr>
      <th>386</th>
      <td>616</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
    </tr>
    <tr>
      <th>387</th>
      <td>617</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2121</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>388</th>
      <td>618</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
    </tr>
    <tr>
      <th>389</th>
      <td>619</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.1970</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
    </tr>
  </tbody>
</table>
<p>390 rows × 15 columns</p>
</div>




```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>instant</th>
      <th>dteday</th>
      <th>season</th>
      <th>mnth</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>weathersit</th>
      <th>temp</th>
      <th>atemp</th>
      <th>hum</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>cnt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>620</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1940</td>
      <td>0</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>621</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1642</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>622</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.20</td>
      <td>0.2121</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>623</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.69</td>
      <td>0.1045</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>624</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>6</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>385</th>
      <td>615</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
    </tr>
    <tr>
      <th>386</th>
      <td>616</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
    </tr>
    <tr>
      <th>387</th>
      <td>617</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2121</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>388</th>
      <td>618</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
    </tr>
    <tr>
      <th>389</th>
      <td>619</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.1970</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
    </tr>
  </tbody>
</table>
<p>390 rows × 15 columns</p>
</div>




```python
dff1 = df1.rename(columns={'instant': 'Serial Num', 'dteday':'Day','weathersit':'Weather info',
'temp':'Temprature','hum':'Humidity','mnth':'Month','cnt':'Count'})
dff1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>atemp</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>620</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1940</td>
      <td>0</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>621</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.64</td>
      <td>0.1642</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>622</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.20</td>
      <td>0.2121</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>3</td>
      <td>5</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>623</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.69</td>
      <td>0.1045</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>624</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>6</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.1818</td>
      <td>0.64</td>
      <td>0.1343</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>385</th>
      <td>615</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
    </tr>
    <tr>
      <th>386</th>
      <td>616</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>0.2273</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
    </tr>
    <tr>
      <th>387</th>
      <td>617</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2121</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>388</th>
      <td>618</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2273</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
    </tr>
    <tr>
      <th>389</th>
      <td>619</td>
      <td>2011-01-29</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.1970</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
    </tr>
  </tbody>
</table>
<p>390 rows × 15 columns</p>
</div>




```python
dff = pd.read_csv(r'C:\Users\RAJUK\OneDrive\Desktop\python\Solution1\dataset1_.csv')
```


```python
dff
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>Celsius</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.81</td>
      <td>0.0000</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0000</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0000</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>4</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.75</td>
      <td>0.0000</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>5</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.75</td>
      <td>0.0000</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>605</th>
      <td>605</td>
      <td>606</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>11</td>
      <td>False</td>
      <td>5</td>
      <td>3</td>
      <td>0.18</td>
      <td>0.2121</td>
      <td>0.93</td>
      <td>0.1045</td>
      <td>0</td>
      <td>30</td>
      <td>30</td>
    </tr>
    <tr>
      <th>606</th>
      <td>606</td>
      <td>607</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>12</td>
      <td>False</td>
      <td>5</td>
      <td>3</td>
      <td>0.18</td>
      <td>0.2121</td>
      <td>0.93</td>
      <td>0.1045</td>
      <td>1</td>
      <td>28</td>
      <td>29</td>
    </tr>
    <tr>
      <th>607</th>
      <td>607</td>
      <td>608</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>13</td>
      <td>False</td>
      <td>5</td>
      <td>3</td>
      <td>0.18</td>
      <td>0.2121</td>
      <td>0.93</td>
      <td>0.1045</td>
      <td>0</td>
      <td>31</td>
      <td>31</td>
    </tr>
    <tr>
      <th>608</th>
      <td>608</td>
      <td>609</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>14</td>
      <td>False</td>
      <td>5</td>
      <td>3</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0000</td>
      <td>2</td>
      <td>36</td>
      <td>38</td>
    </tr>
    <tr>
      <th>609</th>
      <td>609</td>
      <td>610</td>
      <td>2011-01-28</td>
      <td>1</td>
      <td>1</td>
      <td>15</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.20</td>
      <td>0.2576</td>
      <td>0.86</td>
      <td>0.0000</td>
      <td>1</td>
      <td>40</td>
      <td>41</td>
    </tr>
  </tbody>
</table>
<p>610 rows × 16 columns</p>
</div>




```python
final_report = pd.concat([dff,dff1])
final_report 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>Celsius</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
      <th>atemp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>1</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.81</td>
      <td>0.0000</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>2</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0000</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2.0</td>
      <td>3</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0000</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3.0</td>
      <td>4</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.75</td>
      <td>0.0000</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4.0</td>
      <td>5</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.75</td>
      <td>0.0000</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>385</th>
      <td>NaN</td>
      <td>615</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>NaN</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
      <td>0.2273</td>
    </tr>
    <tr>
      <th>386</th>
      <td>NaN</td>
      <td>616</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>NaN</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
      <td>0.2273</td>
    </tr>
    <tr>
      <th>387</th>
      <td>NaN</td>
      <td>617</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>NaN</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
      <td>0.2121</td>
    </tr>
    <tr>
      <th>388</th>
      <td>NaN</td>
      <td>618</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>NaN</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
      <td>0.2273</td>
    </tr>
    <tr>
      <th>389</th>
      <td>NaN</td>
      <td>619</td>
      <td>2011-01-29 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>NaN</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
      <td>0.1970</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 17 columns</p>
</div>




```python
final_report.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 1000 entries, 0 to 389
    Data columns (total 17 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   Unnamed: 0    610 non-null    float64
     1   Serial Num    1000 non-null   int64  
     2   Day           1000 non-null   object 
     3   season        1000 non-null   int64  
     4   Month         1000 non-null   int64  
     5   hr            1000 non-null   int64  
     6   holiday       1000 non-null   bool   
     7   weekday       1000 non-null   int64  
     8   Weather info  1000 non-null   int64  
     9   Temprature    1000 non-null   float64
     10  Celsius       599 non-null    float64
     11  Humidity      1000 non-null   float64
     12  windspeed     1000 non-null   float64
     13  casual        1000 non-null   int64  
     14  registered    1000 non-null   int64  
     15  Count         1000 non-null   int64  
     16  atemp         390 non-null    float64
    dtypes: bool(1), float64(6), int64(9), object(1)
    memory usage: 133.8+ KB
    


```python
final_report.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>Celsius</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
      <th>atemp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>1</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.81</td>
      <td>0.0</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>2</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2.0</td>
      <td>3</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>0.2727</td>
      <td>0.80</td>
      <td>0.0</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3.0</td>
      <td>4</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.75</td>
      <td>0.0</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4.0</td>
      <td>5</td>
      <td>2011-01-01</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.24</td>
      <td>0.2879</td>
      <td>0.75</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_report.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>Celsius</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
      <th>atemp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>385</th>
      <td>NaN</td>
      <td>615</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.24</td>
      <td>NaN</td>
      <td>0.70</td>
      <td>0.1940</td>
      <td>1</td>
      <td>61</td>
      <td>62</td>
      <td>0.2273</td>
    </tr>
    <tr>
      <th>386</th>
      <td>NaN</td>
      <td>616</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>21</td>
      <td>False</td>
      <td>5</td>
      <td>2</td>
      <td>0.22</td>
      <td>NaN</td>
      <td>0.75</td>
      <td>0.1343</td>
      <td>1</td>
      <td>57</td>
      <td>58</td>
      <td>0.2273</td>
    </tr>
    <tr>
      <th>387</th>
      <td>NaN</td>
      <td>617</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>22</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>NaN</td>
      <td>0.65</td>
      <td>0.3582</td>
      <td>0</td>
      <td>26</td>
      <td>26</td>
      <td>0.2121</td>
    </tr>
    <tr>
      <th>388</th>
      <td>NaN</td>
      <td>618</td>
      <td>2011-01-28 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>23</td>
      <td>False</td>
      <td>5</td>
      <td>1</td>
      <td>0.24</td>
      <td>NaN</td>
      <td>0.60</td>
      <td>0.2239</td>
      <td>1</td>
      <td>22</td>
      <td>23</td>
      <td>0.2273</td>
    </tr>
    <tr>
      <th>389</th>
      <td>NaN</td>
      <td>619</td>
      <td>2011-01-29 00:00:00</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>False</td>
      <td>6</td>
      <td>1</td>
      <td>0.22</td>
      <td>NaN</td>
      <td>0.64</td>
      <td>0.3582</td>
      <td>2</td>
      <td>26</td>
      <td>28</td>
      <td>0.1970</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_report.shape
```




    (1000, 17)




```python
final_report.duplicated().sum()
```




    0




```python
final_report.isnull().sum()
```




    Unnamed: 0      390
    Serial Num        0
    Day               0
    season            0
    Month             0
    hr                0
    holiday           0
    weekday           0
    Weather info      0
    Temprature        0
    Celsius         401
    Humidity          0
    windspeed         0
    casual            0
    registered        0
    Count             0
    atemp           610
    dtype: int64




```python
# Columns to drop
columns_to_drop = ['season', 'Unnamed: 0'] 
final_report1 = final_report.drop(columns=columns_to_drop,axis = 1)
```


```python
final_report1 = final_report['Celsius'].fillna(final_report['Celsius'].mean())
final_report1.isnull().sum()
```




    0




```python
final_report1 = final_report['atemp'].fillna(final_report['atemp'].mean())
final_report1.isnull().sum()
```




    0




```python
final_report1.isnull().sum()
```




    0




```python
plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
sns.distplot(final_report['Temprature'])
plt.title('Temprature Distribution')
plt.xlabel('Temprature')
plt.ylabel('Density')

plt.subplot(2, 2, 2)
sns.distplot(final_report['windspeed'])
plt.title('Windspeed Distribution')
plt.xlabel('Windspeed')
plt.ylabel('Density')

plt.subplot(2, 2, 3)
sns.distplot(final_report['atemp'])
plt.title('Atemp Distribution')
plt.xlabel('Atemp')
plt.ylabel('Density')

plt.subplot(2, 2, 4)
sns.distplot(final_report['Humidity'])
plt.title('Humidity Distribution')
plt.xlabel('Humidity')
plt.ylabel('Density')


plt.tight_layout()
plt.show()
```


    
![png](output_25_0.png)
    



```python
final_report['Temprature'].describe()
```




    count    1000.000000
    mean        0.205785
    std         0.078619
    min         0.020000
    25%         0.160000
    50%         0.200000
    75%         0.240000
    max         0.440797
    Name: Temprature, dtype: float64




```python
plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
sns.boxplot(final_report['Temprature'])
plt.title('Temprature outliers')
plt.xlabel('Temprature')
plt.ylabel('Density')

plt.subplot(2, 2, 2)
sns.boxplot(final_report['windspeed'])
plt.title('Windspeed outliers')
plt.xlabel('Windspeed')
plt.ylabel('Density')

plt.subplot(2, 2, 3)
sns.boxplot(final_report['Celsius'])
plt.title('Celsius outliers')
plt.xlabel('Celsius')
plt.ylabel('Density')

plt.subplot(2, 2, 4)
sns.boxplot(final_report['Humidity'])
plt.title('Humidity outliers')
plt.xlabel('Humidity')
plt.ylabel('Density')


plt.tight_layout()
plt.show()
```


    
![png](output_27_0.png)
    



```python
mean_temprature = final_report['Temprature'].mean()
mean_temprature
```




    0.20578478068599815




```python
std_devit = final_report['Temprature'].std()
std_devit
```




    0.07861943695245184




```python
final_report.shape
```




    (1000, 17)




```python
max_value = mean_temprature.mean()+ 3*std_devit
min_value = mean_temprature.mean()- 3*std_devit
```


```python
max_value
```




    0.4416430915433537




```python
min_value
```




    -0.030073530171357388




```python
## For extracting the outlier
Outliers = final_report[(final_report['Temprature']>max_value) | (final_report['Temprature']<min_value)]
```


```python
Outliers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>Celsius</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
      <th>atemp</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
sns.boxplot(x='Weather info',y='Count',data=final_report) 
```




    <Axes: xlabel='Weather info', ylabel='Count'>




    
![png](output_36_1.png)
    



```python
mean_Celsius = final_report['Celsius'].mean()
mean_Celsius
```




    0.19984338418029846




```python
std_devit1 = final_report['Celsius'].std()
std_devit1
```




    0.07854704602186217




```python
max_value1 = mean_Celsius.mean()+ 3*std_devit1
min_value1 = mean_Celsius.mean()- 3*std_devit1
```


```python
max_value1
```




    0.43548452224588496




```python
min_value1
```




    -0.03579775388528805




```python
## For extracting the outlier
Outlier1 = final_report[(final_report['Celsius']>max_value) | (final_report['Celsius']<min_value)]
```


```python
Outlier1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Serial Num</th>
      <th>Day</th>
      <th>season</th>
      <th>Month</th>
      <th>hr</th>
      <th>holiday</th>
      <th>weekday</th>
      <th>Weather info</th>
      <th>Temprature</th>
      <th>Celsius</th>
      <th>Humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>Count</th>
      <th>atemp</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
# Detect outliers of windspeed and capped by z-score 
outliers1 = []
def detect_outliers1(final_report1):
    threshold=3
    mean1 = np.mean(final_report1['windspeed']) # Fixed indentation here
    std = np.std(final_report1['windspeed'])
    threshold = 3

    for i in final_report1['windspeed']: # Iterate through 'windspeed' column, not the entire DataFrame
        z_score = (i-mean1)/std
        if np.abs(z_score)>threshold:
            outliers1.append(i)
    return outliers1 # Return statement should be inside the function
    
```


```python
outliers1
```




    []




```python
df_final=final_report1.describe()
df_final
```




    count    1000.000000
    mean        0.230424
    std         0.043341
    min         0.075800
    25%         0.230424
    50%         0.230424
    75%         0.230424
    max         0.424200
    Name: atemp, dtype: float64




```python
# Assuming  data is in a pandas DataFrame called 'final_report'

plt.figure(figsize=(10, 6))
plt.scatter(final_report['Humidity'], final_report['Count'], c=final_report['Weather info'], cmap='viridis')
plt.xlabel('Humidity')
plt.ylabel('Bike Rental Count')
plt.title('Humidity vs. Bike Rental Count (Colored by Weather)')
plt.colorbar(label='Weather Info')
```




    <matplotlib.colorbar.Colorbar at 0x2579c3a41d0>




    
![png](output_47_1.png)
    



```python

plt.figure(figsize=(14,10))
plot = sns.heatmap(numeric_final_report.corr().round(2), annot=True,
            vmin=-1, vmax=1, center=0, cmap='tab20c_r', robust=True)
plot.set_title('Correlation Matrix of Bike Rental Data') 

```




    Text(0.5, 1.0, 'Correlation Matrix of Bike Rental Data')




    
![png](output_48_1.png)
    



```python
# Get a list of all available colormaps
all_colormaps = plt.colormaps()
```


```python
all_colormaps
```




    ['magma',
     'inferno',
     'plasma',
     'viridis',
     'cividis',
     'twilight',
     'twilight_shifted',
     'turbo',
     'Blues',
     'BrBG',
     'BuGn',
     'BuPu',
     'CMRmap',
     'GnBu',
     'Greens',
     'Greys',
     'OrRd',
     'Oranges',
     'PRGn',
     'PiYG',
     'PuBu',
     'PuBuGn',
     'PuOr',
     'PuRd',
     'Purples',
     'RdBu',
     'RdGy',
     'RdPu',
     'RdYlBu',
     'RdYlGn',
     'Reds',
     'Spectral',
     'Wistia',
     'YlGn',
     'YlGnBu',
     'YlOrBr',
     'YlOrRd',
     'afmhot',
     'autumn',
     'binary',
     'bone',
     'brg',
     'bwr',
     'cool',
     'coolwarm',
     'copper',
     'cubehelix',
     'flag',
     'gist_earth',
     'gist_gray',
     'gist_heat',
     'gist_ncar',
     'gist_rainbow',
     'gist_stern',
     'gist_yarg',
     'gnuplot',
     'gnuplot2',
     'gray',
     'hot',
     'hsv',
     'jet',
     'nipy_spectral',
     'ocean',
     'pink',
     'prism',
     'rainbow',
     'seismic',
     'spring',
     'summer',
     'terrain',
     'winter',
     'Accent',
     'Dark2',
     'Paired',
     'Pastel1',
     'Pastel2',
     'Set1',
     'Set2',
     'Set3',
     'tab10',
     'tab20',
     'tab20b',
     'tab20c',
     'grey',
     'gist_grey',
     'gist_yerg',
     'Grays',
     'magma_r',
     'inferno_r',
     'plasma_r',
     'viridis_r',
     'cividis_r',
     'twilight_r',
     'twilight_shifted_r',
     'turbo_r',
     'Blues_r',
     'BrBG_r',
     'BuGn_r',
     'BuPu_r',
     'CMRmap_r',
     'GnBu_r',
     'Greens_r',
     'Greys_r',
     'OrRd_r',
     'Oranges_r',
     'PRGn_r',
     'PiYG_r',
     'PuBu_r',
     'PuBuGn_r',
     'PuOr_r',
     'PuRd_r',
     'Purples_r',
     'RdBu_r',
     'RdGy_r',
     'RdPu_r',
     'RdYlBu_r',
     'RdYlGn_r',
     'Reds_r',
     'Spectral_r',
     'Wistia_r',
     'YlGn_r',
     'YlGnBu_r',
     'YlOrBr_r',
     'YlOrRd_r',
     'afmhot_r',
     'autumn_r',
     'binary_r',
     'bone_r',
     'brg_r',
     'bwr_r',
     'cool_r',
     'coolwarm_r',
     'copper_r',
     'cubehelix_r',
     'flag_r',
     'gist_earth_r',
     'gist_gray_r',
     'gist_heat_r',
     'gist_ncar_r',
     'gist_rainbow_r',
     'gist_stern_r',
     'gist_yarg_r',
     'gnuplot_r',
     'gnuplot2_r',
     'gray_r',
     'hot_r',
     'hsv_r',
     'jet_r',
     'nipy_spectral_r',
     'ocean_r',
     'pink_r',
     'prism_r',
     'rainbow_r',
     'seismic_r',
     'spring_r',
     'summer_r',
     'terrain_r',
     'winter_r',
     'Accent_r',
     'Dark2_r',
     'Paired_r',
     'Pastel1_r',
     'Pastel2_r',
     'Set1_r',
     'Set2_r',
     'Set3_r',
     'tab10_r',
     'tab20_r',
     'tab20b_r',
     'tab20c_r',
     'rocket',
     'rocket_r',
     'mako',
     'mako_r',
     'icefire',
     'icefire_r',
     'vlag',
     'vlag_r',
     'flare',
     'flare_r',
     'crest',
     'crest_r']




```python
# List of variables to visualize
variables = ['Temprature', 'windspeed', 'Celsius', 'Humidity']

# Function to create and display individual scatterplots with a pause
def visualize_variable(variable_name):
    plt.figure(figsize=(8, 6))  # Adjust figure size as needed
    sns.scatterplot(x=variable_name, y='Count', data=final_report)
    plt.title(f'{variable_name} Visualize')
    plt.xlabel(variable_name)
    plt.ylabel('Count')
    plt.grid(True, linestyle='--', alpha=0.5)  # Add gridlines for better readability
    plt.tight_layout()  # Improve layout for better aesthetics
    plt.show()
    

# Visualize each variable one by one with a pause
for variable in variables:
    visualize_variable(variable)
```


    
![png](output_51_0.png)
    



    
![png](output_51_1.png)
    



    
![png](output_51_2.png)
    



    
![png](output_51_3.png)
    



```python
# List of variables to visualize
variables = ['Temprature', 'windspeed', 'Celsius', 'Humidity']

# Function to create and display individual histograms
def visualize_histogram(variable_name):
    plt.figure(figsize=(8, 6))  # Adjust figure size as needed
    sns.histplot(data=final_report, x=variable_name, bins=20, kde=True, color='skyblue') 
    plt.title(f'{variable_name} visualize')
    plt.xlabel(variable_name)
    plt.ylabel('Frequency')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.show()

# Visualize each variable as a histogram
for variable in variables:
    visualize_histogram(variable)
```


    
![png](output_52_0.png)
    



    
![png](output_52_1.png)
    



    
![png](output_52_2.png)
    



    
![png](output_52_3.png)
    



```python
final_report1.to_excel(r'C:\Users\RAJUK\OneDrive\Desktop\python\Solution1\final_dataset1_2_3.xlsx')
```


```python

```
